public interface Eat {
    public void eatingFood();
    public void eatingCompleted();
}
