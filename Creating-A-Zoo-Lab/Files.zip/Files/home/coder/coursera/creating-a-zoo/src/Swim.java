public interface Swim {
    /** TODO 6: create a new interface named "Swim"
     * and declaring a method inside it
     * named "swimming" with the return type
     * "void"
     **/
    void swimming();
}
